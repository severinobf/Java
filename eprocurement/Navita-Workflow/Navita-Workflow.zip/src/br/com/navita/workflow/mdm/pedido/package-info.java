/**
 * pedidos feitos às operadoras referentes a solicitações de usuários.
 */
/**
 * @author Severino Bento Ferreira Junior
 *
 */
package br.com.navita.workflow.mdm.pedido;