/**
 * 
 */
package br.com.navita.workflow.mdm.model;

/**
 * Estado Civil de uma pessoa
 * 
 * @author Severino Bento Ferreira Junior
 *
 */
public enum MaritalStatus {
	
	SOLTEIRO, CASADO, VIUVO, DESQUITADO, DIVORCIADO, AMASIADO;

}
