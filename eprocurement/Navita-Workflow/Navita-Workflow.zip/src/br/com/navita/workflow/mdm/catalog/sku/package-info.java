/**
 * 
 */
/**
 * operations with skus.
 * 
 * @author Severino Bento Ferreira Junior
 *
 */
package br.com.navita.workflow.mdm.catalog.sku;