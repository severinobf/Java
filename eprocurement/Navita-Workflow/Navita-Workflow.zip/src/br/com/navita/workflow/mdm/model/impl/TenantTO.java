/**
 * 
 */
package br.com.navita.workflow.mdm.model.impl;

import br.com.navita.workflow.mdm.model.AbstractCompanyTO;

/**
 * Definition of a Tenant in Navita's workflow.
 * 
 * @author Severino Bento Ferreira Junior
 *
 */
public class TenantTO extends AbstractCompanyTO {

	/**
	 * generated
	 */
	private static final long serialVersionUID = -7880675660050902054L;

}
