/**
 * 
 */
package br.com.navita.workflow.mdm.process.procurement;


/**
 * @author Severino Bento Ferreira Junior
 *
 */
public class ProcurementException extends Exception {

	public ProcurementException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProcurementException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ProcurementException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ProcurementException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProcurementException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * generated
	 */
	private static final long serialVersionUID = 7838214198601566678L;

}
