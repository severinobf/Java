/**
 * Componente de persistência de gestos de usuário na base noSQL.
 */
/**
 * @author Severino Bento Ferreira Junior
 *
 */
package br.com.navita.workflow.mdm.gesture;