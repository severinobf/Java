/**
 * 
 */
package br.com.navita.workflow.mdm.model;

/**
 * Sexo de uma pessoa
 * 
 * @author Severino Bento Ferreira Junior
 *
 */
public enum Gender {
	
	MALE, FEMALE;

}
