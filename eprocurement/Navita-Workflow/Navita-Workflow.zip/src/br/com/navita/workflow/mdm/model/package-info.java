/**
 * Model:  Common objects for Navita's MDM workflow.
 * Detached from implementation.
 */
/**
 * @author Severino Bento Ferreira Junior
 *
 */
package br.com.navita.workflow.mdm.model;