/**
 * Caso de Uso Solicitar Produto/Serviço.
 * @see "Especificacao de Caso de Uso: Comprar Produto/Servico.doc"
 */
/**
 * @author Severino Bento Ferreira Junior
 *
 */
package br.com.navita.workflow.mdm.process.procurement;