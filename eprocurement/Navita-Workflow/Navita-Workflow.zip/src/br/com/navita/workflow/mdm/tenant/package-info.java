/**
 * 
 */
/**
 * Tenant component
 * 
 * @author Severino Bento Ferreira Junior
 *
 */
package br.com.navita.workflow.mdm.tenant;