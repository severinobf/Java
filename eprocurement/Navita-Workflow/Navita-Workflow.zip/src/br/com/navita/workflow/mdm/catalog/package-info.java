/**
 * Catalogo para o MDM.  Inclui classes gerais e serviços.
 */
/**
 * @author Severino Bento Ferreira Junior
 *
 */
package br.com.navita.workflow.mdm.catalog;